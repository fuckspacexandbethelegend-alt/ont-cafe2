CREATE TABLE "menu_settings" (
	"id" integer PRIMARY KEY DEFAULT 1,
	"scroll_speed" integer DEFAULT 28 NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL,
	CONSTRAINT "menu_settings_single_row" CHECK ("id" = 1)
);
