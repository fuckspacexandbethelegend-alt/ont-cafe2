ALTER TABLE "menu_items" ADD COLUMN "name_en" text;
--> statement-breakpoint
UPDATE "menu_items" AS m SET "name_en" = t.en
FROM (VALUES
  ('أمريكانو بارد', 'Iced Americano'),
  ('بوكس قهوة اليوم', 'Coffee of the Day Box'),
  ('أمريكانو', 'Americano'),
  ('تشوكليت بودينق', 'Chocolate Pudding'),
  ('كابتشينو', 'Cappuccino'),
  ('سبانش لاتيه بارد', 'Iced Spanish Latte'),
  ('أونت تشيز', 'Ont Cheese'),
  ('قهوة اليوم حار - الحجم الكبير', 'Hot Coffee of the Day - Large'),
  ('قهوة اليوم', 'Coffee of the Day'),
  ('قهوة اليوم حار - الحجم الصغير', 'Hot Coffee of the Day - Small'),
  ('قهوة مقطرة باردة', 'Iced Drip Coffee'),
  ('دولتشي كيك', 'Dolce Cake'),
  ('كرات التراميسو', 'Tiramisu Balls'),
  ('بار الفول السوداني', 'Peanut Bar'),
  ('كورتادو', 'Cortado'),
  ('لاتيه بارد', 'Iced Latte'),
  ('ماتشا بارد', 'Iced Matcha'),
  ('فلات وايت', 'Flat White'),
  ('فريدو', 'Freddo'),
  ('إسبريسو', 'Espresso'),
  ('سبانش لاتيه دافئ', 'Hot Spanish Latte'),
  ('انفيوجن', 'Infusion'),
  ('قهوة اليوم باردة - الحجم الكبير', 'Iced Coffee of the Day - Large'),
  ('لاتيه دافئ', 'Hot Latte'),
  ('قهوة اليوم بارد - الحجم الصغير', 'Iced Coffee of the Day - Small'),
  ('ماجيك بار', 'Magic Bar'),
  ('لايرز تشوكلت كيك', 'Layers Chocolate Cake'),
  ('قهوة مقطرة حارة', 'Hot Drip Coffee'),
  ('كركديه بارد', 'Iced Hibiscus'),
  ('كرات البروتين', 'Protein Balls')
) AS t(ar, en)
WHERE m."name" = t.ar AND m."name_en" IS NULL;
